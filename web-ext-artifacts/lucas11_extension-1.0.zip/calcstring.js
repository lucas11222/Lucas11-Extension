document.getElementById('calcstringbuttonsubmit').onclick = function() {
    var finalresult = document.getElementById('firstinput').value + " " +document.getElementById('secondinput').value;
    console.log(finalresult)
    document.getElementById("resultcalcstring").innerHTML = finalresult;
};