document.getElementById('calcstringbutton').onclick = function() {
    document.getElementById('menu').classList.add("hidden");
    document.getElementById('calcstring').classList.remove("hidden");
};
